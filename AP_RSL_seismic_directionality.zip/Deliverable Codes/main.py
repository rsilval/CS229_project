# -*- coding: utf-8 -*-
"""
Created on Wed Jun  2 10:49:33 2021

@author: alanp
"""


# Run benchmark model
exec(open('benchmark_model.py').read())

# Run ridge regression model
exec(open('Ridge_model.py').read())

# Run neural network model
exec(open('Neural_network_model.py').read())

