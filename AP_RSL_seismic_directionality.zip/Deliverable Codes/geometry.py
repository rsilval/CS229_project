# -*- coding: utf-8 -*-
"""
Created on Mon Jun 01 12:42:07 2015

@author: Alan
"""

import numpy as np


def Distance_earth(lat1, lon1, lat2, lon2, R=6371.):
    '''
    Computes the distance between 2 points on the surface of the earth.
    
    Parameters
    ----------
    lat1 : float
        Latitude of the first pont (in degrees).
    lon1 : float
        Longitude of the first pont (in degrees).
    lat2 : float
        Latitude of the second pont (in degrees).
    lon2 : float
        Longitude of the second pont (in degrees).
    R : float
        Radius of the earth used in the analysis
    Returns
    ----------
    distance : float
        Distance between the two points (in km).
    Notes
    ----------
    The earth is assume to be a sphere and the distance follows an arc.
    '''
    
    dLat = (lat2-lat1)*np.pi/180.
    dLon = (lon2-lon1)*np.pi/180.
    a = np.sin(dLat/2.)**2. + np.sin(dLon/2.)**2.*np.cos(lat1*np.pi/180.)*np.cos(lat2*np.pi/180.)
    c = 2.*np.arctan2(np.sqrt(a),np.sqrt(1.-a))
    
    return R*c