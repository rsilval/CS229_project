# -*- coding: utf-8 -*-
"""
@author: alanp
"""

import numpy as np
import pandas as pd
from operator import itemgetter



def generate_x_y(Dmax=100, addCategorical=False):
    
    # Read flatfile
    dtype={"Record Sequence Number": int, "EQID": int, "Earthquake Name": str,
               "Basis for Inference of Surface Rupture":str,
               'Fault Name':str, 'FW/HW Indicator':str, 'Geology':str, 
               'INSTLOC':str,'Site Visited':str, 'NGA Type':str, 'Age':str,
               'Grain Size':str, 'Depositional History':str, 'Basin':str,
               'Instrument Model':str, 'Instrument Type':str, 'Late S-trigger':str,
               'Late P-trigger':str, 'Depth to Top of Shallowest Asperity (km)':str}
    df_NGA = pd.read_csv('Filtered_data.csv', dtype=dtype)
    ind_dict = dict(zip(df_NGA['Record Sequence Number'].values, np.arange(len(df_NGA))))
    
    
    # Get data type indices
    import csv
    with open('Filtered_data_indices.csv', 'r') as file:
        reader = csv.reader(file)
        row1 = next(reader)
        row2 = next(reader)
        row3 = next(reader)
    nCols = len(row1)
    isSiteData = np.zeros(nCols, dtype=int)
    include = np.zeros(nCols, dtype=int)
    dataType = np.zeros(nCols, dtype=int)
    for i in range(nCols):
        if row1[i]=='\xef\xbb\xbf1':
            isSiteData[i] = 1
        else:
            isSiteData[i] = int(row1[i])
        if row2[i]=='':
            include[i] = 0
        else:
            include[i] = int(row2[i])
        if row3[i]=='':
            dataType[i] = 0
        else:
            dataType[i] = int(row3[i])
    
    
    
    # Read csv file with all examples
    df_Examples = pd.read_csv('azimuth_diffs.csv')
    # Remove records without PGA, PGV, PGD
    removeRSN = [829, 1255, 1556, 1595]
    filt = (~df_Examples['RSN1'].isin(removeRSN)) & (~df_Examples['RSN2'].isin(removeRSN))
    df_Examples = df_Examples[filt]
    RSN1 = df_Examples['RSN1'].values
    RSN2 = df_Examples['RSN2'].values
    
    
    
    # Construct Y (output) matrix 
    df_Y_all = df_Examples.loc[:,'T=0.01':]
    
    
    
    # Construct X (input) matrix 
    # Start with distances between sites
    df_X_all = pd.DataFrame(df_Examples['dist'])
    # Include event data
    eventInd = np.where((dataType==1)*(isSiteData==0)*(include==1))[0]
    df_event = df_NGA.iloc[list(itemgetter(*RSN1)(ind_dict)), eventInd]
    for (columnName, columnData) in df_event.iteritems():
        df_X_all[columnName] = columnData.values
    # Include site data
    siteInd = np.where((dataType==1)*(isSiteData==1)*(include==1))[0]
    df_site1 = df_NGA.iloc[list(itemgetter(*RSN1)(ind_dict)), siteInd]
    for (columnName, columnData) in df_site1.iteritems():
        df_X_all['1_'+columnName] = columnData.values
    df_site2 = df_NGA.iloc[list(itemgetter(*RSN2)(ind_dict)), siteInd]
    for (columnName, columnData) in df_site2.iteritems():
        df_X_all['2_'+columnName] = columnData.values
    
    
    
    # Filter dist <= Dmax
    df_X = df_X_all[df_X_all['dist']<=Dmax]
    df_Y = df_Y_all[df_X_all['dist']<=Dmax]
    
    
    # Remove columns with -999 data
    for columnName in df_X:
        if abs(df_X[columnName].min() + 999)<0.01:
            df_X = df_X.drop(columnName, axis=1) 
    
    
    if addCategorical:
        
        # Construct categorical X (input) matrix 
        df_X_cat_all = pd.DataFrame(df_Examples['dist'])
        # Include event data
        eventInd = np.where((dataType==3)*(isSiteData==0)*(include==1))[0]
        df_event = df_NGA.iloc[list(itemgetter(*RSN1)(ind_dict)), eventInd]
        for (columnName, columnData) in df_event.iteritems():
            df_X_cat_all[columnName] = columnData.values
        # Include site data
        siteInd = np.where((dataType==3)*(isSiteData==1)*(include==1))[0]
        df_site1 = df_NGA.iloc[list(itemgetter(*RSN1)(ind_dict)), siteInd]
        for (columnName, columnData) in df_site1.iteritems():
            df_X_cat_all['1_'+columnName] = columnData.values
        df_site2 = df_NGA.iloc[list(itemgetter(*RSN2)(ind_dict)), siteInd]
        for (columnName, columnData) in df_site2.iteritems():
            df_X_cat_all['2_'+columnName] = columnData.values
        
        # Filter dist <= Dmax
        df_X_cat_all = df_X_cat_all.drop(['dist'], axis=1)
        df_X_cat = df_X_cat_all[df_X_all['dist']<=Dmax]
        
        return df_X, df_Y, df_X_cat
    
    else:
        
        return df_X, df_Y


    