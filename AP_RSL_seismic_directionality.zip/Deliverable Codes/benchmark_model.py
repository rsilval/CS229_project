# -*- coding: utf-8 -*-
"""
Created on Thu May  6 10:36:22 2021

@author: alanp
"""

import numpy as np
#import matplotlib
#matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.utils import shuffle
from generate_x_y import generate_x_y
from sklearn.metrics import mean_absolute_error
import os


# Settings
pTrain = 0.8
pTest = 0.2
name = 'Linear'#
addCategorical = False
Dmax = 5
period = 'T=3'

# Import data
if addCategorical:
    df_X, df_Y, df_X_cat = generate_x_y(Dmax, addCategorical=True)
else:
    df_X, df_Y = generate_x_y(Dmax, addCategorical=False)

# Define the output that is used and suffle data
y_single = df_Y[period].values
if addCategorical:
    X, y, X_cat = shuffle(df_X.values, y_single, df_X_cat.values, random_state=1)
else:
    X, y = shuffle(df_X.values, y_single, random_state=1)

# Normalize numerical data
scaler = StandardScaler()
scaler.fit(X)
X_norm = scaler.transform(X)
if addCategorical:
    # Encode categorical data
    encoder = OneHotEncoder(sparse=False)
    X_cat_norm = encoder.fit_transform(X_cat)
    # Join both types of variables
    X_all_norm = np.hstack([X_norm, X_cat_norm])
else:
    X_all_norm = X_norm


i = 0
# Separate data in train and test
nData = len(y)
p1 = int(nData*pTrain)
X_train_norm = X_all_norm[:p1,i]
X_test_norm = X_all_norm[p1:,i]
y_train = y[:p1]
y_test = y[p1:]
X_train_norm = np.asmatrix(X_train_norm)
X_train_norm = np.transpose(X_train_norm)
X_test_norm = np.asmatrix(X_test_norm)
X_test_norm = np.transpose(X_test_norm)

# Train model
reg = LinearRegression().fit(np.asmatrix(X_train_norm), y_train)

#reg = KernelRidge(kernel='linear').fit(X_train_norm, y_train)

y_train_pred = reg.predict(X_train_norm)
R2_train = reg.score(X_train_norm, y_train)
y_test_pred = reg.predict(X_test_norm)
R2_test = reg.score(X_test_norm, y_test)
m_error = mean_absolute_error(y_test_pred, y_test)


# Figures
fig,ax = plt.subplots(1, 2, sharey=True, figsize=(8.5,4))
ax[0].scatter(y_train, y_train_pred)
ax[0].set_title(r'Training data, $R^2$='+'{:.4f}'.format(R2_train),fontsize = 20)
ax[0].set_xlabel(r'True $\Delta \theta$',fontsize = 20)
ax[0].set_ylabel(r'Predicted $\Delta \theta$',fontsize = 20)
ax[0].set_xlim(0, 90)
ax[0].set_ylim(0, 90)
ax[1].scatter(y_test, y_test_pred)
ax[1].set_title(r'Test data, $R^2$='+'{:.4f}'.format(R2_test),fontsize = 20)
ax[1].set_xlabel(r'True $\Delta \theta$',fontsize = 20)
ax[1].set_xlim(0, 90)
ax[1].set_ylim(0, 90)
ax[0].tick_params(labelsize = 16,axis='both')
ax[1].tick_params(labelsize = 16,axis='both')
plt.tight_layout()
plt.savefig(os.path.join('Figures', name+'.pdf'), bbox_inches='tight')


# Study the dependence of each variable
use = ['dist', 'PGA (g)']
typ = [1, 3]  # 1:event, 2:absolute difference, 3: average
xmin = [0, 0]
xmax = [5, 0.2]
nUse = len(use)
for i in range(nUse):

    y_model = np.hstack([y_train_pred, y_test_pred])

    nBins = 40
    if typ[i] == 1:
        ind = df_X.columns.get_loc(use[i])
        x = X[:, ind]
    elif typ[i] == 2:
        ind1 = df_X.columns.get_loc('1_' + use[i])
        ind2 = df_X.columns.get_loc('2_' + use[i])
        x = np.abs(X[:, ind1] - X[:, ind2])
    elif typ[i] == 3:
        ind1 = df_X.columns.get_loc('1_' + use[i])
        ind2 = df_X.columns.get_loc('2_' + use[i])
        x = (X[:, ind1] + X[:, ind2]) / 2
    bins = np.linspace(x.min(), x.max(), nBins + 1)
    meanX = (bins[1:] + bins[:-1]) / 2
    meanY = np.zeros(nBins)
    meanY_model = np.zeros(nBins)
    ci_hw = np.zeros(nBins)
    ci_hw_model = np.zeros(nBins)
    for j in range(nBins):
        inds = np.where((x > bins[j]) * (x <= bins[j + 1]))[0]
        meanY[j] = np.mean(y[inds])
        ci_hw[j] = 1.96 * np.std(y[inds]) / np.sqrt(len(inds))
        meanY_model[j] = np.mean(y_model[inds])
        ci_hw_model[j] = 1.96 * np.std(y_model[inds]) / np.sqrt(len(inds))

    plt.figure()
    plt.scatter(x, y, color='0.8', alpha=0.5, label='Data')
    plt.errorbar(meanX, meanY, ci_hw, marker='o', color='C1', label='Moving average of the data')
    plt.errorbar(meanX, meanY_model, ci_hw_model, marker='o', color='C0', label='Moving average of the model')
    if typ[i] == 1:
        plt.xlabel(use[i])
    elif typ[i] == 2:
        plt.xlabel('Absolute difference of ' + use[i])
    elif typ[i] == 3:
        plt.xlabel('Average of ' + use[i])
    plt.ylabel(r'$\Delta \theta$')
    plt.ylim(0, 90)
    plt.xlim(xmin[i], xmax[i])
    plt.legend()
    plt.savefig(os.path.join('Figures', name + '_' + use[i].replace('/', '') + '.pdf'), bbox_inches='tight')
    plt.savefig(os.path.join('Figures', name + '_' + use[i].replace('/', '') + '.png'), dpi=200, bbox_inches='tight')

